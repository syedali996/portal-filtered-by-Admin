
# Type Enum

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `QR_CONTENT` |
| `QR_IMAGE_LINK` |

