
# Optin Response Qr Info

## Structure

`OptinResponseQrInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`TypeEnum`](../../doc/models/type-enum.md) | Required | - |
| `source` | `String` | Required | - |

## Example (as XML)

```xml
<OptinResponseQrInfo>
  <type>QR_CONTENT</type>
  <source>source4</source>
</OptinResponseQrInfo>
```

