
# Validate Optin Response

'validate-optin' Response - General Elements

## Structure

`ValidateOptinResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `result` | [`Result`](../../doc/models/result.md) | Required | The 'result' element is defined in every response type. It is used to convey the outcome of an API request. |
| `merchant_id` | `String` | Required | Boku assigned merchant ID<br>**Constraints**: *Maximum Length*: `50` |
| `merchant_request_id` | `String` | Required | Merchant assigned unique request id<br>**Constraints**: *Maximum Length*: `50` |
| `optin_request_id` | `String` | Optional | The merchant assigned ID used as `merchant-request-id` in the original opt-in call<br>**Constraints**: *Maximum Length*: `50` |
| `optin_id` | `String` | Optional | Boku assigned opt-in id<br>**Constraints**: *Maximum Length*: `24` |
| `optin_state` | [`OptinState`](../../doc/models/optin-state.md) | Optional | Gives the state of the opt-in at the time this response was returned |
| `payment_method` | `String` | Optional | The payment method selected<br>**Constraints**: *Maximum Length*: `50` |
| `optin_type` | [`OptinTypeEnum`](../../doc/models/optin-type-enum.md) | Optional | Which method to use to perform opt-in. |

## Example (as XML)

```xml
<validate-optin-response>
  <result>
    <reason-code>0</reason-code>
    <message>Operation Successful</message>
    <retriable>false</retriable>
    <status>OK</status>
  </result>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-request-id>2032405</merchant-request-id>
  <optin-id>IVXecDoa2f6Y3oOqp1f7</optin-id>
  <optin-state>
    <optin-status>pending-confirm</optin-status>
    <country>JP</country>
    <network-id>jp-super</network-id>
    <account-identifier>te****st@boku.com</account-identifier>
    <issuer-unique-user-id>cc1c4f3</issuer-unique-user-id>
  </optin-state>
  <optin-type>hosted</optin-type>
  <payment-method>superwallet</payment-method>
</validate-optin-response>
```

