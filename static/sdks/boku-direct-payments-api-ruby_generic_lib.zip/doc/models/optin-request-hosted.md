
# Optin Request Hosted

Container element for parameters relevant when optin-type is 'hosted'

## Structure

`OptinRequestHosted`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `forward_url` | `String` | Required | Supplies the URL for Boku to redirect the consumer back to the merchant UI to complete authentication.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `2048` |
| `use_mobile_flow` | `TrueClass\|FalseClass` | Optional | True if a mobile-optimized optin flow should be used for this request, false otherwise.<br><br>Example: A non-mobile-optimized flow could display a QR code on the user's mobile. The user would be unable to scan the QR code because they are already on their mobile.<br><br>A mobile-optimized flow could display a mobile login page to the user.<br>**Default**: `false` |
| `qr_info` | [`OptinRequestQrInfo`](../../doc/models/optin-request-qr-info.md) | Optional | - |

## Example (as XML)

```xml
<hosted>
  <forward-url>https://merchant.com/redirect/2032405</forward-url>
</hosted>
```

