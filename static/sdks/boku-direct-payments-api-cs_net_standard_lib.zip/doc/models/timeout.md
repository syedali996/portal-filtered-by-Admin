
# Timeout

Specifies how long to block waiting for a response

## Structure

`Timeout`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `After` | `long` | Required | Maximum time to block before returning a response, in milliseconds. The value `0` means do not block, and there is no way to specify infinity.<br>**Constraints**: `>= 0`, `<= 60000` |

## Example (as XML)

```xml
<timeout after="10000" />
```

