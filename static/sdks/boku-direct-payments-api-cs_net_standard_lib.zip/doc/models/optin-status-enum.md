
# Optin Status Enum

Gives the status of the opt-in at the time this response was returned

## Enumeration

`OptinStatusEnum`

## Fields

| Name |
|  --- |
| `Pendingvalidate` |
| `Pendingconfirm` |
| `Active` |
| `Closed` |

