
# Optin Request

'optin' Request - General Parameters

## Structure

`OptinRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Country` | `string` | Required | Country code in ISO 3166-1-alpha-2 standard<br>**Constraints**: *Pattern*: `^[A-Z]{2}$` |
| `MerchantId` | `string` | Required | Boku assigned merchant ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `MerchantRequestId` | `string` | Required | Merchant assigned unique request ID.<br><br>Multiple requests received with the same request ID in this field will be handled idempotently within the idempotency window.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `MerchantConsumerId` | `string` | Optional | Consumer id assigned by merchant<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64` |
| `PaymentMethod` | `string` | Required | The payment method the consumer has selected:<br><br>* Each wallet provider will be its own payment method. A list of available values will be provided on demand.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `OptinType` | `string` | Required, Constant | Which method to use to perform opt-in.<br>**Default**: `"hosted"` |
| `Hosted` | [`Models.OptinRequestHosted`](../../doc/models/optin-request-hosted.md) | Required | Container element for parameters relevant when optin-type is 'hosted' |
| `SellerOfRecord` | [`Models.SellerOfRecord`](../../doc/models/seller-of-record.md) | Optional | Optin and Charge Request API can be made for specific Seller of Record previously registered with Boku. |
| `NotificationUrl` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |

## Example (as XML)

```xml
<optin-request>
  <country>JP</country>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-request-id>2032405</merchant-request-id>
  <payment-method>superwallet</payment-method>
  <optin-type>hosted</optin-type>
  <hosted>
    <forward-url>https://merchant.com/redirect/2032405</forward-url>
  </hosted>
</optin-request>
```

