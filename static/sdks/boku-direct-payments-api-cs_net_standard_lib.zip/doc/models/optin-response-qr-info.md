
# Optin Response Qr Info

## Structure

`OptinResponseQrInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`Models.TypeEnum`](../../doc/models/type-enum.md) | Required | - |
| `Source` | `string` | Required | - |

## Example (as XML)

```xml
<OptinResponseQrInfo>
  <type>QR_CONTENT</type>
  <source>source4</source>
</OptinResponseQrInfo>
```

