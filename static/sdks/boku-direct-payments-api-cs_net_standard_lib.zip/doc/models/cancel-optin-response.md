
# Cancel Optin Response

'cancel-optin' Response - General Elements

## Structure

`CancelOptinResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Result` | [`Models.Result`](../../doc/models/result.md) | Required | The 'result' element is defined in every response type. It is used to convey the outcome of an API request. |
| `MerchantId` | `string` | Required | Boku assigned merchant ID<br>**Constraints**: *Maximum Length*: `50` |
| `MerchantRequestId` | `string` | Required | Merchant assigned request ID<br>**Constraints**: *Maximum Length*: `50` |
| `OptinId` | `string` | Required | Boku assigned consumer opt-in ID<br>**Constraints**: *Maximum Length*: `24` |
| `OptinType` | [`Models.OptinTypeEnum?`](../../doc/models/optin-type-enum.md) | Optional | Which method to use to perform opt-in. |
| `OptinState` | [`Models.OptinState`](../../doc/models/optin-state.md) | Optional | Gives the state of the opt-in at the time this response was returned |

## Example (as XML)

```xml
<cancel-optin-response>
  <result>
    <reason-code>0</reason-code>
    <message>Operation Successful</message>
    <retriable>false</retriable>
    <status>OK</status>
  </result>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-request-id>1002006</merchant-request-id>
  <optin-id>IVXecDoa2f6Y3oOqp1f7</optin-id>
  <optin-state>
    <optin-status>closed</optin-status>
    <country>DE</country>
    <network-id>de-super</network-id>
  </optin-state>
  <optin-type>hosted</optin-type>
</cancel-optin-response>
```

