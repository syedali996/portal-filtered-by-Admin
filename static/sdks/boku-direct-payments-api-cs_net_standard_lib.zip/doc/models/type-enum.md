
# Type Enum

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `QRCONTENT` |
| `QRIMAGELINK` |

