
# Result

The 'result' element is defined in every response type. It is used to convey the outcome of an API request.

## Structure

`Result`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Status` | [`Models.ResultStatusEnum`](../../doc/models/result-status-enum.md) | Required | The status of the operation |
| `ReasonCode` | `int` | Required | Provides additional information for the status |
| `Message` | `string` | Required | Description of the reason code |
| `Retriable` | `bool` | Required | **true** if the request can be retried; **false** otherwise |
| `RetryDelay` | `int?` | Optional | Minimum milliseconds to delay before re-trying request |
| `InvalidRequestFields` | [`List<Models.InvalidRequestField>`](../../doc/models/invalid-request-field.md) | Optional | - |

## Example (as XML)

```xml
<result>
  <reason-code>0</reason-code>
  <message>Operation Successful</message>
  <retriable>false</retriable>
  <status>OK</status>
</result>
```

