// <copyright file="BokuDirectPaymentsAPIClient.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using BokuDirectPaymentsAPI.Standard.Controllers;
    using BokuDirectPaymentsAPI.Standard.Http.Client;
    using BokuDirectPaymentsAPI.Standard.Utilities;

    /// <summary>
    /// The gateway for the SDK. This class acts as a factory for Controller and
    /// holds the configuration of the SDK.
    /// </summary>
    public sealed class BokuDirectPaymentsAPIClient : IConfiguration
    {
        // A map of environments and their corresponding servers/baseurls
        private static readonly Dictionary<Environment, Dictionary<Enum, string>> EnvironmentsMap =
            new Dictionary<Environment, Dictionary<Enum, string>>
        {
            {
                Environment.Production, new Dictionary<Enum, string>
                {
                    { Server.Default, "https://{country}-api4-stage.boku.com" },
                }
            },
            {
                Environment.Environment2, new Dictionary<Enum, string>
                {
                    { Server.Default, "https://{country}-api4.boku.com" },
                }
            },
        };

        private readonly GlobalConfiguration globalConfiguration;
        private const string userAgent = "APIMATIC 3.0";
        private readonly Lazy<ConsumerRegistrationController> consumerRegistration;

        private BokuDirectPaymentsAPIClient(
            Environment environment,
            string country,
            IHttpClientConfiguration httpClientConfiguration)
        {
            this.Environment = environment;
            this.Country = country;
            this.HttpClientConfiguration = httpClientConfiguration;

            globalConfiguration = new GlobalConfiguration.Builder()
                .HttpConfiguration(httpClientConfiguration)
                .ServerUrls(EnvironmentsMap[environment], Server.Default)
                .Parameters(globalParameter => globalParameter
                    .Template(templateParameter => templateParameter.Setup("country", this.Country)))
                .UserAgent(userAgent)
                .Build();


            this.consumerRegistration = new Lazy<ConsumerRegistrationController>(
                () => new ConsumerRegistrationController(globalConfiguration));
        }

        /// <summary>
        /// Gets ConsumerRegistrationController controller.
        /// </summary>
        public ConsumerRegistrationController ConsumerRegistrationController => this.consumerRegistration.Value;

        /// <summary>
        /// Gets the configuration of the Http Client associated with this client.
        /// </summary>
        public IHttpClientConfiguration HttpClientConfiguration { get; }

        /// <summary>
        /// Gets Environment.
        /// Current API environment.
        /// </summary>
        public Environment Environment { get; }

        /// <summary>
        /// Gets Country.
        /// Country code in ISO 3166-1-alpha-2 standard.
        /// </summary>
        public string Country { get; }


        /// <summary>
        /// Gets the URL for a particular alias in the current environment and appends
        /// it with template parameters.
        /// </summary>
        /// <param name="alias">Default value:DEFAULT.</param>
        /// <returns>Returns the baseurl.</returns>
        public string GetBaseUri(Server alias = Server.Default)
        {
            return globalConfiguration.ServerUrl(alias);
        }

        /// <summary>
        /// Creates an object of the BokuDirectPaymentsAPIClient using the values provided for the builder.
        /// </summary>
        /// <returns>Builder.</returns>
        public Builder ToBuilder()
        {
            Builder builder = new Builder()
                .Environment(this.Environment)
                .Country(this.Country)
                .HttpClientConfig(config => config.Build());

            return builder;
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            return
                $"Environment = {this.Environment}, " +
                $"Country = {this.Country}, " +
                $"HttpClientConfiguration = {this.HttpClientConfiguration}, ";
        }

        /// <summary>
        /// Creates the client using builder.
        /// </summary>
        /// <returns> BokuDirectPaymentsAPIClient.</returns>
        internal static BokuDirectPaymentsAPIClient CreateFromEnvironment()
        {
            var builder = new Builder();

            string environment = System.Environment.GetEnvironmentVariable("BOKU_DIRECT_PAYMENTS_API_STANDARD_ENVIRONMENT");
            string country = System.Environment.GetEnvironmentVariable("BOKU_DIRECT_PAYMENTS_API_STANDARD_COUNTRY");

            if (environment != null)
            {
                builder.Environment(ApiHelper.JsonDeserialize<Environment>($"\"{environment}\""));
            }

            if (country != null)
            {
                builder.Country(country);
            }

            return builder.Build();
        }

        /// <summary>
        /// Builder class.
        /// </summary>
        public class Builder
        {
            private Environment environment = BokuDirectPaymentsAPI.Standard.Environment.Production;
            private string country = "jp";
            private HttpClientConfiguration.Builder httpClientConfig = new HttpClientConfiguration.Builder();

            /// <summary>
            /// Sets Environment.
            /// </summary>
            /// <param name="environment"> Environment. </param>
            /// <returns> Builder. </returns>
            public Builder Environment(Environment environment)
            {
                this.environment = environment;
                return this;
            }

            /// <summary>
            /// Sets Country.
            /// </summary>
            /// <param name="country"> Country. </param>
            /// <returns> Builder. </returns>
            public Builder Country(string country)
            {
                this.country = country ?? throw new ArgumentNullException(nameof(country));
                return this;
            }

            /// <summary>
            /// Sets HttpClientConfig.
            /// </summary>
            /// <param name="action"> Action. </param>
            /// <returns>Builder.</returns>
            public Builder HttpClientConfig(Action<HttpClientConfiguration.Builder> action)
            {
                if (action is null)
                {
                    throw new ArgumentNullException(nameof(action));
                }

                action(this.httpClientConfig);
                return this;
            }

           

            /// <summary>
            /// Creates an object of the BokuDirectPaymentsAPIClient using the values provided for the builder.
            /// </summary>
            /// <returns>BokuDirectPaymentsAPIClient.</returns>
            public BokuDirectPaymentsAPIClient Build()
            {

                return new BokuDirectPaymentsAPIClient(
                    environment,
                    country,
                    httpClientConfig.Build());
            }
        }
    }
}
