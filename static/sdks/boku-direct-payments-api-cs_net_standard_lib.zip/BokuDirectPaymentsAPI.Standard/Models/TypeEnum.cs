// <copyright file="TypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// TypeEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    [XmlRoot("Type")]
    public enum TypeEnum
    {
        /// <summary>
        /// QRCONTENT.
        /// </summary>
        [XmlEnum("QR_CONTENT")]
        [EnumMember(Value = "QR_CONTENT")]
        QRCONTENT,

        /// <summary>
        /// QRIMAGELINK.
        /// </summary>
        [XmlEnum("QR_IMAGE_LINK")]
        [EnumMember(Value = "QR_IMAGE_LINK")]
        QRIMAGELINK
    }
}