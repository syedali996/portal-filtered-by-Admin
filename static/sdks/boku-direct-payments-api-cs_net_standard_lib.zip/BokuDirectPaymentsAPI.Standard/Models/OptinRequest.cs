// <copyright file="OptinRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// OptinRequest.
    /// </summary>
    [XmlRootAttribute("optin-request")]
    public class OptinRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OptinRequest"/> class.
        /// </summary>
        public OptinRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="OptinRequest"/> class.
        /// </summary>
        /// <param name="country">country.</param>
        /// <param name="merchantId">merchantId.</param>
        /// <param name="merchantRequestId">merchantRequestId.</param>
        /// <param name="paymentMethod">paymentMethod.</param>
        /// <param name="optinType">optinType.</param>
        /// <param name="hosted">hosted.</param>
        /// <param name="merchantConsumerId">merchantConsumerId.</param>
        /// <param name="sellerOfRecord">sellerOfRecord.</param>
        /// <param name="notificationUrl">notificationUrl.</param>
        public OptinRequest(
            string country,
            string merchantId,
            string merchantRequestId,
            string paymentMethod,
            string optinType,
            Models.OptinRequestHosted hosted,
            string merchantConsumerId = null,
            Models.SellerOfRecord sellerOfRecord = null,
            string notificationUrl = null)
        {
            this.Country = country;
            this.MerchantId = merchantId;
            this.MerchantRequestId = merchantRequestId;
            this.MerchantConsumerId = merchantConsumerId;
            this.PaymentMethod = paymentMethod;
            this.OptinType = optinType;
            this.Hosted = hosted;
            this.SellerOfRecord = sellerOfRecord;
            this.NotificationUrl = notificationUrl;
        }

        /// <summary>
        /// Country code in ISO 3166-1-alpha-2 standard
        /// </summary>
        [JsonProperty("country")]
        [XmlElement("country")]
        public string Country { get; set; }

        /// <summary>
        /// Boku assigned merchant ID
        /// </summary>
        [JsonProperty("merchantId")]
        [XmlElement("merchant-id")]
        public string MerchantId { get; set; }

        /// <summary>
        /// Merchant assigned unique request ID.
        /// Multiple requests received with the same request ID in this field will be handled idempotently within the idempotency window.
        /// </summary>
        [JsonProperty("merchantRequestId")]
        [XmlElement("merchant-request-id")]
        public string MerchantRequestId { get; set; }

        /// <summary>
        /// Consumer id assigned by merchant
        /// </summary>
        [JsonProperty("merchantConsumerId", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("merchant-consumer-id")]
        public string MerchantConsumerId { get; set; }

        /// <summary>
        /// The payment method the consumer has selected:
        /// * Each wallet provider will be its own payment method. A list of available values will be provided on demand.
        /// </summary>
        [JsonProperty("paymentMethod")]
        [XmlElement("payment-method")]
        public string PaymentMethod { get; set; }

        /// <summary>
        /// Which method to use to perform opt-in.
        /// </summary>
        [JsonProperty("optinType")]
        [XmlElement("optin-type")]
        public string OptinType { get; set; }

        /// <summary>
        /// Container element for parameters relevant when optin-type is 'hosted'
        /// </summary>
        [JsonProperty("hosted")]
        [XmlElement("hosted")]
        public Models.OptinRequestHosted Hosted { get; set; }

        /// <summary>
        /// Optin and Charge Request API can be made for specific Seller of Record previously registered with Boku.
        /// </summary>
        [JsonProperty("sellerOfRecord", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("seller-of-record")]
        public Models.SellerOfRecord SellerOfRecord { get; set; }

        /// <summary>
        /// Gets or sets NotificationUrl.
        /// </summary>
        [JsonProperty("notificationUrl", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("notification-url")]
        public string NotificationUrl { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"OptinRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is OptinRequest other &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.MerchantId == null && other.MerchantId == null) || (this.MerchantId?.Equals(other.MerchantId) == true)) &&
                ((this.MerchantRequestId == null && other.MerchantRequestId == null) || (this.MerchantRequestId?.Equals(other.MerchantRequestId) == true)) &&
                ((this.MerchantConsumerId == null && other.MerchantConsumerId == null) || (this.MerchantConsumerId?.Equals(other.MerchantConsumerId) == true)) &&
                ((this.PaymentMethod == null && other.PaymentMethod == null) || (this.PaymentMethod?.Equals(other.PaymentMethod) == true)) &&
                ((this.OptinType == null && other.OptinType == null) || (this.OptinType?.Equals(other.OptinType) == true)) &&
                ((this.Hosted == null && other.Hosted == null) || (this.Hosted?.Equals(other.Hosted) == true)) &&
                ((this.SellerOfRecord == null && other.SellerOfRecord == null) || (this.SellerOfRecord?.Equals(other.SellerOfRecord) == true)) &&
                ((this.NotificationUrl == null && other.NotificationUrl == null) || (this.NotificationUrl?.Equals(other.NotificationUrl) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country == string.Empty ? "" : this.Country)}");
            toStringOutput.Add($"this.MerchantId = {(this.MerchantId == null ? "null" : this.MerchantId == string.Empty ? "" : this.MerchantId)}");
            toStringOutput.Add($"this.MerchantRequestId = {(this.MerchantRequestId == null ? "null" : this.MerchantRequestId == string.Empty ? "" : this.MerchantRequestId)}");
            toStringOutput.Add($"this.MerchantConsumerId = {(this.MerchantConsumerId == null ? "null" : this.MerchantConsumerId == string.Empty ? "" : this.MerchantConsumerId)}");
            toStringOutput.Add($"this.PaymentMethod = {(this.PaymentMethod == null ? "null" : this.PaymentMethod == string.Empty ? "" : this.PaymentMethod)}");
            toStringOutput.Add($"this.OptinType = {(this.OptinType == null ? "null" : this.OptinType == string.Empty ? "" : this.OptinType)}");
            toStringOutput.Add($"this.Hosted = {(this.Hosted == null ? "null" : this.Hosted.ToString())}");
            toStringOutput.Add($"this.SellerOfRecord = {(this.SellerOfRecord == null ? "null" : this.SellerOfRecord.ToString())}");
            toStringOutput.Add($"this.NotificationUrl = {(this.NotificationUrl == null ? "null" : this.NotificationUrl == string.Empty ? "" : this.NotificationUrl)}");
        }
    }
}