// <copyright file="CancelOptinRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CancelOptinRequest.
    /// </summary>
    [XmlRootAttribute("cancel-optin-request")]
    public class CancelOptinRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CancelOptinRequest"/> class.
        /// </summary>
        public CancelOptinRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CancelOptinRequest"/> class.
        /// </summary>
        /// <param name="merchantId">merchantId.</param>
        /// <param name="merchantRequestId">merchantRequestId.</param>
        /// <param name="optinId">optinId.</param>
        public CancelOptinRequest(
            string merchantId,
            string merchantRequestId,
            string optinId)
        {
            this.MerchantId = merchantId;
            this.MerchantRequestId = merchantRequestId;
            this.OptinId = optinId;
        }

        /// <summary>
        /// Boku assigned merchant ID
        /// </summary>
        [JsonProperty("merchantId")]
        [XmlElement("merchant-id")]
        public string MerchantId { get; set; }

        /// <summary>
        /// Merchant assigned unique request ID.
        /// Multiple requests received with the same request ID in this field will be handled idempotently within the idempotency window.
        /// </summary>
        [JsonProperty("merchantRequestId")]
        [XmlElement("merchant-request-id")]
        public string MerchantRequestId { get; set; }

        /// <summary>
        /// Boku provided opt-in ID for the consumer
        /// </summary>
        [JsonProperty("optinId")]
        [XmlElement("optin-id")]
        public string OptinId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CancelOptinRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CancelOptinRequest other &&
                ((this.MerchantId == null && other.MerchantId == null) || (this.MerchantId?.Equals(other.MerchantId) == true)) &&
                ((this.MerchantRequestId == null && other.MerchantRequestId == null) || (this.MerchantRequestId?.Equals(other.MerchantRequestId) == true)) &&
                ((this.OptinId == null && other.OptinId == null) || (this.OptinId?.Equals(other.OptinId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MerchantId = {(this.MerchantId == null ? "null" : this.MerchantId == string.Empty ? "" : this.MerchantId)}");
            toStringOutput.Add($"this.MerchantRequestId = {(this.MerchantRequestId == null ? "null" : this.MerchantRequestId == string.Empty ? "" : this.MerchantRequestId)}");
            toStringOutput.Add($"this.OptinId = {(this.OptinId == null ? "null" : this.OptinId == string.Empty ? "" : this.OptinId)}");
        }
    }
}