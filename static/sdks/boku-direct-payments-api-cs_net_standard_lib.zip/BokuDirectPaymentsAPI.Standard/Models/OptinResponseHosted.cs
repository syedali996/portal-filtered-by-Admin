// <copyright file="OptinResponseHosted.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// OptinResponseHosted.
    /// </summary>
    [XmlRootAttribute("hosted")]
    public class OptinResponseHosted
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OptinResponseHosted"/> class.
        /// </summary>
        public OptinResponseHosted()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="OptinResponseHosted"/> class.
        /// </summary>
        /// <param name="optinUrl">optinUrl.</param>
        /// <param name="qrInfo">qrInfo.</param>
        public OptinResponseHosted(
            string optinUrl,
            Models.OptinResponseQrInfo qrInfo = null)
        {
            this.OptinUrl = optinUrl;
            this.QrInfo = qrInfo;
        }

        /// <summary>
        /// Boku provided URL that provides the opt-in UI for the consumer.
        /// </summary>
        [JsonProperty("optinUrl")]
        [XmlElement("optin-url")]
        public string OptinUrl { get; set; }

        /// <summary>
        /// Gets or sets QrInfo.
        /// </summary>
        [JsonProperty("qrInfo", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("OptinResponseQrInfo")]
        public Models.OptinResponseQrInfo QrInfo { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"OptinResponseHosted : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is OptinResponseHosted other &&
                ((this.OptinUrl == null && other.OptinUrl == null) || (this.OptinUrl?.Equals(other.OptinUrl) == true)) &&
                ((this.QrInfo == null && other.QrInfo == null) || (this.QrInfo?.Equals(other.QrInfo) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.OptinUrl = {(this.OptinUrl == null ? "null" : this.OptinUrl == string.Empty ? "" : this.OptinUrl)}");
            toStringOutput.Add($"this.QrInfo = {(this.QrInfo == null ? "null" : this.QrInfo.ToString())}");
        }
    }
}