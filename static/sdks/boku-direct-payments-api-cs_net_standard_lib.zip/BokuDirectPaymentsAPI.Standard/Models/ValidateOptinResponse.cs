// <copyright file="ValidateOptinResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ValidateOptinResponse.
    /// </summary>
    [XmlRootAttribute("validate-optin-response")]
    public class ValidateOptinResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateOptinResponse"/> class.
        /// </summary>
        public ValidateOptinResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidateOptinResponse"/> class.
        /// </summary>
        /// <param name="result">result.</param>
        /// <param name="merchantId">merchantId.</param>
        /// <param name="merchantRequestId">merchantRequestId.</param>
        /// <param name="optinRequestId">optinRequestId.</param>
        /// <param name="optinId">optinId.</param>
        /// <param name="optinState">optinState.</param>
        /// <param name="paymentMethod">paymentMethod.</param>
        /// <param name="optinType">optinType.</param>
        public ValidateOptinResponse(
            Models.Result result,
            string merchantId,
            string merchantRequestId,
            string optinRequestId = null,
            string optinId = null,
            Models.OptinState optinState = null,
            string paymentMethod = null,
            Models.OptinTypeEnum? optinType = null)
        {
            this.Result = result;
            this.MerchantId = merchantId;
            this.MerchantRequestId = merchantRequestId;
            this.OptinRequestId = optinRequestId;
            this.OptinId = optinId;
            this.OptinState = optinState;
            this.PaymentMethod = paymentMethod;
            this.OptinType = optinType;
        }

        /// <summary>
        /// The 'result' element is defined in every response type. It is used to convey the outcome of an API request.
        /// </summary>
        [JsonProperty("result")]
        [XmlElement("result")]
        public Models.Result Result { get; set; }

        /// <summary>
        /// Boku assigned merchant ID
        /// </summary>
        [JsonProperty("merchantId")]
        [XmlElement("merchant-id")]
        public string MerchantId { get; set; }

        /// <summary>
        /// Merchant assigned unique request id
        /// </summary>
        [JsonProperty("merchantRequestId")]
        [XmlElement("merchant-request-id")]
        public string MerchantRequestId { get; set; }

        /// <summary>
        /// The merchant assigned ID used as `merchant-request-id` in the original opt-in call
        /// </summary>
        [JsonProperty("optinRequestId", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("optin-request-id")]
        public string OptinRequestId { get; set; }

        /// <summary>
        /// Boku assigned opt-in id
        /// </summary>
        [JsonProperty("optinId", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("optin-id")]
        public string OptinId { get; set; }

        /// <summary>
        /// Gives the state of the opt-in at the time this response was returned
        /// </summary>
        [JsonProperty("optinState", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("optin-state")]
        public Models.OptinState OptinState { get; set; }

        /// <summary>
        /// The payment method selected
        /// </summary>
        [JsonProperty("paymentMethod", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("payment-method")]
        public string PaymentMethod { get; set; }

        /// <summary>
        /// Which method to use to perform opt-in.
        /// </summary>
        [JsonProperty("optinType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("optin-type")]
        public Models.OptinTypeEnum? OptinType { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ValidateOptinResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ValidateOptinResponse other &&
                ((this.Result == null && other.Result == null) || (this.Result?.Equals(other.Result) == true)) &&
                ((this.MerchantId == null && other.MerchantId == null) || (this.MerchantId?.Equals(other.MerchantId) == true)) &&
                ((this.MerchantRequestId == null && other.MerchantRequestId == null) || (this.MerchantRequestId?.Equals(other.MerchantRequestId) == true)) &&
                ((this.OptinRequestId == null && other.OptinRequestId == null) || (this.OptinRequestId?.Equals(other.OptinRequestId) == true)) &&
                ((this.OptinId == null && other.OptinId == null) || (this.OptinId?.Equals(other.OptinId) == true)) &&
                ((this.OptinState == null && other.OptinState == null) || (this.OptinState?.Equals(other.OptinState) == true)) &&
                ((this.PaymentMethod == null && other.PaymentMethod == null) || (this.PaymentMethod?.Equals(other.PaymentMethod) == true)) &&
                ((this.OptinType == null && other.OptinType == null) || (this.OptinType?.Equals(other.OptinType) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Result = {(this.Result == null ? "null" : this.Result.ToString())}");
            toStringOutput.Add($"this.MerchantId = {(this.MerchantId == null ? "null" : this.MerchantId == string.Empty ? "" : this.MerchantId)}");
            toStringOutput.Add($"this.MerchantRequestId = {(this.MerchantRequestId == null ? "null" : this.MerchantRequestId == string.Empty ? "" : this.MerchantRequestId)}");
            toStringOutput.Add($"this.OptinRequestId = {(this.OptinRequestId == null ? "null" : this.OptinRequestId == string.Empty ? "" : this.OptinRequestId)}");
            toStringOutput.Add($"this.OptinId = {(this.OptinId == null ? "null" : this.OptinId == string.Empty ? "" : this.OptinId)}");
            toStringOutput.Add($"this.OptinState = {(this.OptinState == null ? "null" : this.OptinState.ToString())}");
            toStringOutput.Add($"this.PaymentMethod = {(this.PaymentMethod == null ? "null" : this.PaymentMethod == string.Empty ? "" : this.PaymentMethod)}");
            toStringOutput.Add($"this.OptinType = {(this.OptinType == null ? "null" : this.OptinType.ToString())}");
        }
    }
}