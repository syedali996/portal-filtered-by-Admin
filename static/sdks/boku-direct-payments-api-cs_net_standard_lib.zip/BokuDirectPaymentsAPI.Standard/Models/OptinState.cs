// <copyright file="OptinState.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// OptinState.
    /// </summary>
    [XmlRootAttribute("optin-state")]
    public class OptinState
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OptinState"/> class.
        /// </summary>
        public OptinState()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="OptinState"/> class.
        /// </summary>
        /// <param name="optinStatus">optinStatus.</param>
        /// <param name="country">country.</param>
        /// <param name="networkId">networkId.</param>
        /// <param name="accountIdentifier">accountIdentifier.</param>
        /// <param name="issuerUniqueUserId">issuerUniqueUserId.</param>
        public OptinState(
            Models.OptinStatusEnum optinStatus,
            string country,
            string networkId = null,
            string accountIdentifier = null,
            string issuerUniqueUserId = null)
        {
            this.OptinStatus = optinStatus;
            this.NetworkId = networkId;
            this.Country = country;
            this.AccountIdentifier = accountIdentifier;
            this.IssuerUniqueUserId = issuerUniqueUserId;
        }

        /// <summary>
        /// Gives the status of the opt-in at the time this response was returned
        /// </summary>
        [JsonProperty("optinStatus", ItemConverterType = typeof(StringEnumConverter))]
        [XmlElement("optin-status")]
        public Models.OptinStatusEnum OptinStatus { get; set; }

        /// <summary>
        /// The internal network ID of the user, as declared in `network-info` -> `network[id]`
        /// </summary>
        [JsonProperty("networkId", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("network-id")]
        public string NetworkId { get; set; }

        /// <summary>
        /// Country code in ISO 3166-1-alpha-2 standard
        /// </summary>
        [JsonProperty("country")]
        [XmlElement("country")]
        public string Country { get; set; }

        /// <summary>
        /// Free-text consumer account identifier provided by the payment provider. This value will be recognizable to the user and might not be unique.
        /// </summary>
        [JsonProperty("accountIdentifier", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("account-identifier")]
        public string AccountIdentifier { get; set; }

        /// <summary>
        /// Unique user id provided by the payment provider. This value could be an id that is not recognizable to the user.
        /// </summary>
        [JsonProperty("issuerUniqueUserId", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("issuer-unique-user-id")]
        public string IssuerUniqueUserId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"OptinState : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is OptinState other &&
                this.OptinStatus.Equals(other.OptinStatus) &&
                ((this.NetworkId == null && other.NetworkId == null) || (this.NetworkId?.Equals(other.NetworkId) == true)) &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.AccountIdentifier == null && other.AccountIdentifier == null) || (this.AccountIdentifier?.Equals(other.AccountIdentifier) == true)) &&
                ((this.IssuerUniqueUserId == null && other.IssuerUniqueUserId == null) || (this.IssuerUniqueUserId?.Equals(other.IssuerUniqueUserId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.OptinStatus = {this.OptinStatus}");
            toStringOutput.Add($"this.NetworkId = {(this.NetworkId == null ? "null" : this.NetworkId == string.Empty ? "" : this.NetworkId)}");
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country == string.Empty ? "" : this.Country)}");
            toStringOutput.Add($"this.AccountIdentifier = {(this.AccountIdentifier == null ? "null" : this.AccountIdentifier == string.Empty ? "" : this.AccountIdentifier)}");
            toStringOutput.Add($"this.IssuerUniqueUserId = {(this.IssuerUniqueUserId == null ? "null" : this.IssuerUniqueUserId == string.Empty ? "" : this.IssuerUniqueUserId)}");
        }
    }
}