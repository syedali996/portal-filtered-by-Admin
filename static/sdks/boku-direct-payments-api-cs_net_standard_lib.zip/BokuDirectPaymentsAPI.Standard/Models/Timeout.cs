// <copyright file="Timeout.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Timeout.
    /// </summary>
    [XmlRootAttribute("timeout")]
    public class Timeout
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Timeout"/> class.
        /// </summary>
        public Timeout()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Timeout"/> class.
        /// </summary>
        /// <param name="after">after.</param>
        public Timeout(
            long after)
        {
            this.After = after;
        }

        /// <summary>
        /// Maximum time to block before returning a response, in milliseconds. The value `0` means do not block, and there is no way to specify infinity.
        /// </summary>
        [JsonProperty("after")]
        [XmlAttribute("after")]
        public long After { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Timeout : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Timeout other &&
                this.After.Equals(other.After);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.After = {this.After}");
        }
    }
}