// <copyright file="OptinStatusEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// OptinStatusEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    [XmlRoot("optin-status")]
    public enum OptinStatusEnum
    {
        /// <summary>
        /// Pendingvalidate.
        /// </summary>
        [XmlEnum("pending-validate")]
        [EnumMember(Value = "pending-validate")]
        Pendingvalidate,

        /// <summary>
        /// Pendingconfirm.
        /// </summary>
        [XmlEnum("pending-confirm")]
        [EnumMember(Value = "pending-confirm")]
        Pendingconfirm,

        /// <summary>
        /// Active.
        /// </summary>
        [XmlEnum("active")]
        [EnumMember(Value = "active")]
        Active,

        /// <summary>
        /// Closed.
        /// </summary>
        [XmlEnum("closed")]
        [EnumMember(Value = "closed")]
        Closed
    }
}