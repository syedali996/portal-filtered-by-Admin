// <copyright file="ConsumerRegistrationController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Http.Client;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// ConsumerRegistrationController.
    /// </summary>
    public class ConsumerRegistrationController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerRegistrationController"/> class.
        /// </summary>
        internal ConsumerRegistrationController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// The 'optin' call initiates the consumer authentication process. After an `optin` call, an opt-in is usually in status `pending-validate`.
        /// The optin call types are.
        /// * 'hosted' - redirect the consumer to an issuer-provided UI to perform verification.
        /// The 'optin' call is used in conjunction with the following related methods in order to complete consumer approval:.
        /// * 'validate-optin' - identify and validate the billing account the consumer is registering as   their payment method.
        /// * 'confirm-optin' - confirm that the associated 'optin' should be activated for billing.
        /// It is possible to restrict an optin to be used for a single charge by specifying the 'terms' element. When provided, the system will only allow a single 'charge' request to be made for this optin.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.OptinResponse response from the API call.</returns>
        public Models.OptinResponse Optin(
                Models.ContentTypeEnum contentType,
                Models.OptinRequest body)
            => CoreHelper.RunTask(OptinAsync(contentType, body));

        /// <summary>
        /// The 'optin' call initiates the consumer authentication process. After an `optin` call, an opt-in is usually in status `pending-validate`.
        /// The optin call types are.
        /// * 'hosted' - redirect the consumer to an issuer-provided UI to perform verification.
        /// The 'optin' call is used in conjunction with the following related methods in order to complete consumer approval:.
        /// * 'validate-optin' - identify and validate the billing account the consumer is registering as   their payment method.
        /// * 'confirm-optin' - confirm that the associated 'optin' should be activated for billing.
        /// It is possible to restrict an optin to be used for a single charge by specifying the 'terms' element. When provided, the system will only allow a single 'charge' request to be made for this optin.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.OptinResponse response from the API call.</returns>
        public async Task<Models.OptinResponse> OptinAsync(
                Models.ContentTypeEnum contentType,
                Models.OptinRequest body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.OptinResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/optin/3.0/optin")
                  .XmlBodySerializer(serializer => XmlUtility.ToXml(body, "optin-request")))
              .ResponseHandler(_responseHandler => _responseHandler
                   .Deserializer(_response => XmlUtility.FromXml<Models.OptinResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// The main purpose of an opt-in is to identify and verify the payment method that the end-user wants to register. In the process, the user confirms that they have control over the corresponding payment method. Once an opt-in has begun via an `optin` API call, the `validate-optin` call is used to complete this verification and in most cases retrieve the end-user details such as the account identifier of the user.
        /// Specifically.
        /// * **hosted**: Confirm successful authentication via opt-in UI, and retrieve the account   identifier of the user.
        /// After a successful `validate-optin` call, an opt-in should usually be in status `pending-confirm` awaiting a call to `confirm-optin`.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.ValidateOptinResponse response from the API call.</returns>
        public Models.ValidateOptinResponse ValidateOptin(
                Models.ContentTypeEnum contentType,
                Models.ValidateOptinRequest body)
            => CoreHelper.RunTask(ValidateOptinAsync(contentType, body));

        /// <summary>
        /// The main purpose of an opt-in is to identify and verify the payment method that the end-user wants to register. In the process, the user confirms that they have control over the corresponding payment method. Once an opt-in has begun via an `optin` API call, the `validate-optin` call is used to complete this verification and in most cases retrieve the end-user details such as the account identifier of the user.
        /// Specifically.
        /// * **hosted**: Confirm successful authentication via opt-in UI, and retrieve the account   identifier of the user.
        /// After a successful `validate-optin` call, an opt-in should usually be in status `pending-confirm` awaiting a call to `confirm-optin`.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ValidateOptinResponse response from the API call.</returns>
        public async Task<Models.ValidateOptinResponse> ValidateOptinAsync(
                Models.ContentTypeEnum contentType,
                Models.ValidateOptinRequest body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ValidateOptinResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/optin/3.0/validate-optin")
                  .XmlBodySerializer(serializer => XmlUtility.ToXml(body, "validate-optin-request")))
              .ResponseHandler(_responseHandler => _responseHandler
                   .Deserializer(_response => XmlUtility.FromXml<Models.ValidateOptinResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Assuming an opt-in is in state `pending-confirm` (i.e. all necessary information about the end-user has already been collected), this call confirms that the opt-in should be activated for billing (after a successful call, optin-status should be `active`).
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.ConfirmOptinResponse response from the API call.</returns>
        public Models.ConfirmOptinResponse ConfirmOptin(
                Models.ContentTypeEnum contentType,
                Models.ConfirmOptinRequest body)
            => CoreHelper.RunTask(ConfirmOptinAsync(contentType, body));

        /// <summary>
        /// Assuming an opt-in is in state `pending-confirm` (i.e. all necessary information about the end-user has already been collected), this call confirms that the opt-in should be activated for billing (after a successful call, optin-status should be `active`).
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ConfirmOptinResponse response from the API call.</returns>
        public async Task<Models.ConfirmOptinResponse> ConfirmOptinAsync(
                Models.ContentTypeEnum contentType,
                Models.ConfirmOptinRequest body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ConfirmOptinResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/optin/3.0/confirm-optin")
                  .XmlBodySerializer(serializer => XmlUtility.ToXml(body, "confirm-optin-request")))
              .ResponseHandler(_responseHandler => _responseHandler
                   .Deserializer(_response => XmlUtility.FromXml<Models.ConfirmOptinResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// The purpose of the ‘cancel-optin’ API is for deactivating the consumer’s opt-in stored by Boku and the issuer.
        /// A merchant can use this method in the following possible scenarios:.
        /// * User contacts the merchant requesting to remove their payment method.
        /// * Merchant determines that the consumer’s billing account has encountered a permanent error   that should not be retried in the future.
        /// A cancel-optin request **must** be sent when a user removes the payment method from the merchant account. Various payment methods enforce a 1:1 mapping, that is, a single payment method account can only be associated to a single merchant account. In the case that the merchant does not call cancel-optin, a user would be unable to associate their payment method account with any other merchant account, even though the user has already requested to remove the payment method from the merchant account.
        /// The 'optin-id' received from the 'optin' request at the time the consumer added their payment method must be supplied in the 'cancel-optin' request.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.CancelOptinResponse response from the API call.</returns>
        public Models.CancelOptinResponse CancelOptin(
                Models.ContentTypeEnum contentType,
                Models.CancelOptinRequest body)
            => CoreHelper.RunTask(CancelOptinAsync(contentType, body));

        /// <summary>
        /// The purpose of the ‘cancel-optin’ API is for deactivating the consumer’s opt-in stored by Boku and the issuer.
        /// A merchant can use this method in the following possible scenarios:.
        /// * User contacts the merchant requesting to remove their payment method.
        /// * Merchant determines that the consumer’s billing account has encountered a permanent error   that should not be retried in the future.
        /// A cancel-optin request **must** be sent when a user removes the payment method from the merchant account. Various payment methods enforce a 1:1 mapping, that is, a single payment method account can only be associated to a single merchant account. In the case that the merchant does not call cancel-optin, a user would be unable to associate their payment method account with any other merchant account, even though the user has already requested to remove the payment method from the merchant account.
        /// The 'optin-id' received from the 'optin' request at the time the consumer added their payment method must be supplied in the 'cancel-optin' request.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CancelOptinResponse response from the API call.</returns>
        public async Task<Models.CancelOptinResponse> CancelOptinAsync(
                Models.ContentTypeEnum contentType,
                Models.CancelOptinRequest body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CancelOptinResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/optin/3.0/cancel-optin")
                  .XmlBodySerializer(serializer => XmlUtility.ToXml(body, "cancel-optin-request")))
              .ResponseHandler(_responseHandler => _responseHandler
                   .Deserializer(_response => XmlUtility.FromXml<Models.CancelOptinResponse>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}