
# Cancel Optin Request

'cancel-optin' Request - General Parameters

## Structure

`CancelOptinRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `merchantId` | `string` | Required | Boku assigned merchant ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | getMerchantId(): string | setMerchantId(string merchantId): void |
| `merchantRequestId` | `string` | Required | Merchant assigned unique request ID.<br><br>Multiple requests received with the same request ID in this field will be handled idempotently within the idempotency window.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | getMerchantRequestId(): string | setMerchantRequestId(string merchantRequestId): void |
| `optinId` | `string` | Required | Boku provided opt-in ID for the consumer<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | getOptinId(): string | setOptinId(string optinId): void |

## Example (as XML)

```xml
<cancel-optin-request>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-request-id>1002006</merchant-request-id>
  <optin-id>IVXecDoa2f6Y3oOqp1f7</optin-id>
</cancel-optin-request>
```

