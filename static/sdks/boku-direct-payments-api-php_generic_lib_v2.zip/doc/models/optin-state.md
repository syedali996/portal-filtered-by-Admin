
# Optin State

Gives the state of the opt-in at the time this response was returned

## Structure

`OptinState`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `optinStatus` | [`string (OptinStatusEnum)`](../../doc/models/optin-status-enum.md) | Required | Gives the status of the opt-in at the time this response was returned | getOptinStatus(): string | setOptinStatus(string optinStatus): void |
| `networkId` | `?string` | Optional | The internal network ID of the user, as declared in `network-info` -> `network[id]`<br>**Constraints**: *Maximum Length*: `10` | getNetworkId(): ?string | setNetworkId(?string networkId): void |
| `country` | `string` | Required | Country code in ISO 3166-1-alpha-2 standard<br>**Constraints**: *Pattern*: `^[A-Z]{2}$` | getCountry(): string | setCountry(string country): void |
| `accountIdentifier` | `?string` | Optional | Free-text consumer account identifier provided by the payment provider. This value will be recognizable to the user and might not be unique.<br>**Constraints**: *Maximum Length*: `100` | getAccountIdentifier(): ?string | setAccountIdentifier(?string accountIdentifier): void |
| `issuerUniqueUserId` | `?string` | Optional | Unique user id provided by the payment provider. This value could be an id that is not recognizable to the user.<br>**Constraints**: *Maximum Length*: `255` | getIssuerUniqueUserId(): ?string | setIssuerUniqueUserId(?string issuerUniqueUserId): void |

## Example (as XML)

```xml
<optin-state>
  <optin-status>pending-validate</optin-status>
  <country>JP</country>
  <network-id>jp-super</network-id>
  <account-identifier>te****st@boku.com</account-identifier>
  <issuer-unique-user-id>cc1c4f3</issuer-unique-user-id>
</optin-state>
```

