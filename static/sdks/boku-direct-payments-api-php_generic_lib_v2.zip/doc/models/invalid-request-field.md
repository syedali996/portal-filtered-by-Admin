
# Invalid Request Field

Provides per-field error information in the case where the submitted request did not satisfy validation constraints.

## Structure

`InvalidRequestField`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `path` | `?string` | Optional | Property path of the field that was in error. The element or attribute name is given in camel-case, with nested objects delimited by `.` (period)<br><br>If there are multiple distinct errors regarding a particular field, it may appear more than once. I.e. `field[path]` is not necessarily unique. | getPath(): ?string | setPath(?string path): void |
| `reason` | `?string` | Optional | A descriptive reason why the field was invalid. This message is not localized and so is not appropriate for user messaging. | getReason(): ?string | setReason(?string reason): void |

## Example (as XML)

```xml
<field path="hosted" reason="may not be null" />
```

