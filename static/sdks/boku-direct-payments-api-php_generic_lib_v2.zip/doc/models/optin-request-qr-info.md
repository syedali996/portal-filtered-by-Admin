
# Optin Request Qr Info

## Structure

`OptinRequestQrInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string (TypeEnum)`](../../doc/models/type-enum.md) | Required | - | getType(): string | setType(string type): void |

## Example (as XML)

```xml
<OptinRequestQrInfo>
  <type>QR_CONTENT</type>
</OptinRequestQrInfo>
```

