
# Result

The 'result' element is defined in every response type. It is used to convey the outcome of an API request.

## Structure

`Result`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `status` | [`string (ResultStatusEnum)`](../../doc/models/result-status-enum.md) | Required | The status of the operation | getStatus(): string | setStatus(string status): void |
| `reasonCode` | `int` | Required | Provides additional information for the status | getReasonCode(): int | setReasonCode(int reasonCode): void |
| `message` | `string` | Required | Description of the reason code | getMessage(): string | setMessage(string message): void |
| `retriable` | `bool` | Required | **true** if the request can be retried; **false** otherwise | getRetriable(): bool | setRetriable(bool retriable): void |
| `retryDelay` | `?int` | Optional | Minimum milliseconds to delay before re-trying request | getRetryDelay(): ?int | setRetryDelay(?int retryDelay): void |
| `invalidRequestFields` | [`?(InvalidRequestField[])`](../../doc/models/invalid-request-field.md) | Optional | - | getInvalidRequestFields(): ?array | setInvalidRequestFields(?array invalidRequestFields): void |

## Example (as XML)

```xml
<result>
  <reason-code>0</reason-code>
  <message>Operation Successful</message>
  <retriable>false</retriable>
  <status>OK</status>
</result>
```

