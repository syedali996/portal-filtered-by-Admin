
# Optin Response Qr Info

## Structure

`OptinResponseQrInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string (TypeEnum)`](../../doc/models/type-enum.md) | Required | - | getType(): string | setType(string type): void |
| `source` | `string` | Required | - | getSource(): string | setSource(string source): void |

## Example (as XML)

```xml
<OptinResponseQrInfo>
  <type>QR_CONTENT</type>
  <source>source4</source>
</OptinResponseQrInfo>
```

