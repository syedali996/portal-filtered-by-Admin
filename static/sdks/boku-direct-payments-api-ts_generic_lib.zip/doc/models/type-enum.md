
# Type Enum

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `qRCONTENT` |
| `qRIMAGELINK` |

