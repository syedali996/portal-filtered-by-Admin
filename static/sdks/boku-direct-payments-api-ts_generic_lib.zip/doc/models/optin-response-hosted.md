
# Optin Response Hosted

Provides information for proceeding with a hosted opt-in

## Structure

`OptinResponseHosted`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `optinUrl` | `string` | Required | Boku provided URL that provides the opt-in UI for the consumer.<br>**Constraints**: *Maximum Length*: `2048` |
| `qrInfo` | [`OptinResponseQrInfo \| undefined`](../../doc/models/optin-response-qr-info.md) | Optional | - |

## Example (as XML)

```xml
<hosted>
  <optin-url>https://www.issuer.com/optin/2032405</optin-url>
</hosted>
```

