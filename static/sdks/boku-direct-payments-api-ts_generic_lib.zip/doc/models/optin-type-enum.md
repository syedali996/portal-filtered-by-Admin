
# Optin Type Enum

Which method to use to perform opt-in.

## Enumeration

`OptinTypeEnum`

## Fields

| Name |
|  --- |
| `hosted` |

