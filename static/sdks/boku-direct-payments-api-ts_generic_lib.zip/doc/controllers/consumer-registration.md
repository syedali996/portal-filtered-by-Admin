# Consumer Registration

```ts
const consumerRegistrationController = new ConsumerRegistrationController(client);
```

## Class Name

`ConsumerRegistrationController`

## Methods

* [Optin](../../doc/controllers/consumer-registration.md#optin)
* [Validate Optin](../../doc/controllers/consumer-registration.md#validate-optin)
* [Confirm Optin](../../doc/controllers/consumer-registration.md#confirm-optin)
* [Cancel Optin](../../doc/controllers/consumer-registration.md#cancel-optin)


# Optin

The 'optin' call initiates the consumer authentication process. After an `optin` call, an opt-in is usually in status `pending-validate`.

The optin call types are

* 'hosted' - redirect the consumer to an issuer-provided UI to perform verification.

The 'optin' call is used in conjunction with the following related methods in order to complete consumer approval:

* 'validate-optin' - identify and validate the billing account the consumer is registering as   their payment method.
* 'confirm-optin' - confirm that the associated 'optin' should be activated for billing.

It is possible to restrict an optin to be used for a single charge by specifying the 'terms' element. When provided, the system will only allow a single 'charge' request to be made for this optin.

```ts
async optin(
  contentType: ContentTypeEnum,
  body: OptinRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<OptinResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Required | - |
| `body` | [`OptinRequest`](../../doc/models/optin-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`OptinResponse`](../../doc/models/optin-response.md)

## Example Usage

```ts
const contentType = 'application/xml';
const bodyHosted: OptinRequestHosted = {
  forwardUrl: 'https://merchant.com/redirect/2032405',
};

const bodySellerOfRecord: SellerOfRecord = {
  id: '73tdolramou0m6jnqyb6pkk3',
};

const body: OptinRequest = {
  country: 'JP',
  merchantId: 'gatewaymerchant',
  merchantRequestId: '2032405',
  paymentMethod: 'superwallet',
  optinType: 'hosted',
  hosted: bodyHosted,
};
body.sellerOfRecord = bodySellerOfRecord;

try {
  const { result, ...httpResponse } = await consumerRegistrationController.optin(contentType, body);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response *(as XML)*

```xml
<optin-response>
  <result>
    <reason-code>0</reason-code>
    <message>Operation Successful</message>
    <retriable>false</retriable>
    <status>OK</status>
  </result>
  <timestamp>2015-02-40 04:44:16</timestamp>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-request-id>2032405</merchant-request-id>
  <optin-id>IVXecDoa2f6Y3oOqp1f7</optin-id>
  <optin-state>
    <optin-status>pending-validate</optin-status>
    <country>JP</country>
    <network-id>jp-super</network-id>
    <account-identifier>te****st@boku.com</account-identifier>
    <issuer-unique-user-id>cc1c4f3</issuer-unique-user-id>
  </optin-state>
  <optin-type>hosted</optin-type>
  <hosted>
    <optin-url>https://www.issuer.com/optin/2032405</optin-url>
  </hosted>
  <payment-method>superwallet</payment-method>
</optin-response>
```


# Validate Optin

The main purpose of an opt-in is to identify and verify the payment method that the end-user wants to register. In the process, the user confirms that they have control over the corresponding payment method. Once an opt-in has begun via an `optin` API call, the `validate-optin` call is used to complete this verification and in most cases retrieve the end-user details such as the account identifier of the user.

Specifically

* **hosted**: Confirm successful authentication via opt-in UI, and retrieve the account   identifier of the user.

After a successful `validate-optin` call, an opt-in should usually be in status `pending-confirm` awaiting a call to `confirm-optin`.

```ts
async validateOptin(
  contentType: ContentTypeEnum,
  body: ValidateOptinRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ValidateOptinResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Required | - |
| `body` | [`ValidateOptinRequest`](../../doc/models/validate-optin-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`ValidateOptinResponse`](../../doc/models/validate-optin-response.md)

## Example Usage

```ts
const contentType = 'application/xml';
const body: ValidateOptinRequest = {
  merchantId: 'gatewaymerchant',
  merchantRequestId: '2032405',
  optinType: 'hosted',
};
body.optinId = 'IVXecDoa2f6Y3oOqp1f7';

try {
  const { result, ...httpResponse } = await consumerRegistrationController.validateOptin(contentType, body);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response *(as XML)*

```xml
<validate-optin-response>
  <result>
    <reason-code>0</reason-code>
    <message>Operation Successful</message>
    <retriable>false</retriable>
    <status>OK</status>
  </result>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-request-id>2032405</merchant-request-id>
  <optin-id>IVXecDoa2f6Y3oOqp1f7</optin-id>
  <optin-state>
    <optin-status>pending-confirm</optin-status>
    <country>JP</country>
    <network-id>jp-super</network-id>
    <account-identifier>te****st@boku.com</account-identifier>
    <issuer-unique-user-id>cc1c4f3</issuer-unique-user-id>
  </optin-state>
  <optin-type>hosted</optin-type>
  <payment-method>superwallet</payment-method>
</validate-optin-response>
```


# Confirm Optin

Assuming an opt-in is in state `pending-confirm` (i.e. all necessary information about the end-user has already been collected), this call confirms that the opt-in should be activated for billing (after a successful call, optin-status should be `active`).

```ts
async confirmOptin(
  contentType: ContentTypeEnum,
  body: ConfirmOptinRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ConfirmOptinResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Required | - |
| `body` | [`ConfirmOptinRequest`](../../doc/models/confirm-optin-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`ConfirmOptinResponse`](../../doc/models/confirm-optin-response.md)

## Example Usage

```ts
const contentType = 'application/xml';
const body: ConfirmOptinRequest = {
  merchantId: 'gatewaymerchant',
  merchantRequestId: '1002004',
};
body.optinId = 'IVXecDoa2f6Y3oOqp1f7';

try {
  const { result, ...httpResponse } = await consumerRegistrationController.confirmOptin(contentType, body);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response *(as XML)*

```xml
<confirm-optin-response>
  <result>
    <reason-code>0</reason-code>
    <message>Operation Successful</message>
    <retriable>false</retriable>
    <status>OK</status>
  </result>
  <timestamp>2015-02-40 04:44:16</timestamp>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-request-id>1002004</merchant-request-id>
  <optin-request-id>1002001</optin-request-id>
  <optin-id>IVXecDoa2f6Y3oOqp1f7</optin-id>
  <optin-state>
    <optin-status>active</optin-status>
    <country>JP</country>
    <network-id>jp-super</network-id>
    <account-identifier>te****st@boku.com</account-identifier>
    <issuer-unique-user-id>cc1c4f3</issuer-unique-user-id>
  </optin-state>
  <optin-type>hosted</optin-type>
  <payment-method>superwallet</payment-method>
</confirm-optin-response>
```


# Cancel Optin

The purpose of the ‘cancel-optin’ API is for deactivating the consumer’s opt-in stored by Boku and the issuer.

A merchant can use this method in the following possible scenarios:

* User contacts the merchant requesting to remove their payment method
* Merchant determines that the consumer’s billing account has encountered a permanent error   that should not be retried in the future

A cancel-optin request **must** be sent when a user removes the payment method from the merchant account. Various payment methods enforce a 1:1 mapping, that is, a single payment method account can only be associated to a single merchant account. In the case that the merchant does not call cancel-optin, a user would be unable to associate their payment method account with any other merchant account, even though the user has already requested to remove the payment method from the merchant account.

The 'optin-id' received from the 'optin' request at the time the consumer added their payment method must be supplied in the 'cancel-optin' request.

```ts
async cancelOptin(
  contentType: ContentTypeEnum,
  body: CancelOptinRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<CancelOptinResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contentType` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Required | - |
| `body` | [`CancelOptinRequest`](../../doc/models/cancel-optin-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`CancelOptinResponse`](../../doc/models/cancel-optin-response.md)

## Example Usage

```ts
const contentType = 'application/xml';
const body: CancelOptinRequest = {
  merchantId: 'gatewaymerchant',
  merchantRequestId: '1002006',
  optinId: 'IVXecDoa2f6Y3oOqp1f7',
};

try {
  const { result, ...httpResponse } = await consumerRegistrationController.cancelOptin(contentType, body);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response *(as XML)*

```xml
<cancel-optin-response>
  <result>
    <reason-code>0</reason-code>
    <message>Operation Successful</message>
    <retriable>false</retriable>
    <status>OK</status>
  </result>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-request-id>1002006</merchant-request-id>
  <optin-id>IVXecDoa2f6Y3oOqp1f7</optin-id>
  <optin-state>
    <optin-status>closed</optin-status>
    <country>DE</country>
    <network-id>de-super</network-id>
  </optin-state>
  <optin-type>hosted</optin-type>
</cancel-optin-response>
```

