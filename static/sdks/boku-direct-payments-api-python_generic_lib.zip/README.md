
# Getting Started with Boku Direct Payments API

## Introduction

### API Security

Security is a significant consideration for payment platforms. As part of the registration process for each registered merchant account, merchants receive a security key used to authenticate communications in either direction.

Developers should consult the [Boku API Signature Authentication Guide](page:guides/api-signature-authentication-guide) for additional details with respect to implementing security on the Boku APIs.

### API Usage

When a consumer chooses to use a local payment-method (wallet), the consumer must go through an 'optin' flow to authenticate. This is accomplished using a redirect to the issuer's app or website where the consumer authenticates and completes the opt-in process.

After the consumer adds their local payment-method (wallet), as their registered payment method, the 'charge' method is used to charge the consumer's local payment-method.

If a customer decides to refund a transaction, the 'refund-charge' method can be used to refund the transaction.

### API Versioning

The Boku Payment Gateway API is versioned to provide support for changes to functionality without affecting existing integrations.  Each API URL includes version information that enables distinct functionality across different versions.

There are several types of changes that could result in a new API version:

1. New API functionality – new APIs, new parameters, additional information in responses, improved error reporting.
2. Deprecated API functionality – deprecated APIs, deprecated parameters, deprecated error messages.
3. Changes in functionality – existing functional behavior changes such as the returned result of a call. A warning is changed to an error.  Validation becomes stricter or more lenient.

In these cases, Boku will release a new API version through a new endpoint(s). When new versions of existing APIs are added, support for existing versions is maintained.  Unless otherwise stated, as a rule, compatibility is maintained across versions.  Prior supported endpoints should have unchanged behavior. If an API is deprecated and scheduled to be removed, a notice of not less than 6 months will be given.  Requests for extensions to this period can be considered.

Boku may make changes to the API within an existing version without changing the version number. An example of a non-versioning change would be the addition of an optional field to a request or to a response.

### API Calls

#### URL Scheme

All the below API calls are against URLs that follow the pattern,

`https://${api-node}.boku.com/${api-family}/${api-version}/${api-call}`

Definitions for the above placeholders:

* **api-node**: This follows the pattern '${country}-api4' (e.g. 'us-api4').
  * 'country' is the two letter country code of the end-user's payment-method against which the call is made.
  * The country code is required and is used for more efficient routing of the request.
  * The country code in the url must match the country code supplied in the `optin-request`.`country` element.
* **api-family**: Groups a family of related API methods.
  * In this API, family is either one of:
    * 'optin' - For interacting with the user or handset to obtain billing approval.
    * 'billing' - For actually performing billing operations against the user.
* **api-version**: In this version of the API, this value is always the string '3.0'.
  * Calls under different version numbers may be used in the future to introduce non-compatible API changes.
* **api-call**: The name particular API call or method to invoke, for example 'charge' or 'refund-charge'.
  * This usually matches the XML root element name, sans the '-request' suffix.

Fully qualified API call URLs are documented with each of the example calls detailed below.

## Building

You must have Python `3 >=3.7, <= 3.10` installed on your system to install and run this SDK. This SDK package depends on other Python packages like pytest, jsonpickle etc. These dependencies are defined in the `requirements.txt` file that comes with the SDK. To resolve these dependencies, you can use the PIP Dependency manager. Install it by following steps at [https://pip.pypa.io/en/stable/installing/](https://pip.pypa.io/en/stable/installing/).

Python and PIP executables should be defined in your PATH. Open command prompt and type `pip --version`. This should display the version of the PIP Dependency Manager installed if your installation was successful and the paths are properly defined.

* Using command line, navigate to the directory containing the generated files (including `requirements.txt`) for the SDK.
* Run the command `pip install -r requirements.txt`. This should install all the required dependencies.

![Building SDK - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Bokudirectpaymentsapi-Python&step=installDependencies)

## Installation

The following section explains how to use the bokudirectpaymentsapi library in a new project.

### 1. Open Project in an IDE

Open up a Python IDE like PyCharm. The basic workflow presented here is also applicable if you prefer using a different editor or IDE.

![Open project in PyCharm - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Bokudirectpaymentsapi-Python&step=pyCharm)

Click on `Open` in PyCharm to browse to your generated SDK directory and then click `OK`.

![Open project in PyCharm - Step 2](https://apidocs.io/illustration/python?workspaceFolder=Bokudirectpaymentsapi-Python&step=openProject0)

The project files will be displayed in the side bar as follows:

![Open project in PyCharm - Step 3](https://apidocs.io/illustration/python?workspaceFolder=Bokudirectpaymentsapi-Python&projectName=bokudirectpaymentsapi&step=openProject1)

### 2. Add a new Test Project

Create a new directory by right clicking on the solution name as shown below:

![Add a new project in PyCharm - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Bokudirectpaymentsapi-Python&projectName=bokudirectpaymentsapi&step=createDirectory)

Name the directory as "test".

![Add a new project in PyCharm - Step 2](https://apidocs.io/illustration/python?workspaceFolder=Bokudirectpaymentsapi-Python&step=nameDirectory)

Add a python file to this project.

![Add a new project in PyCharm - Step 3](https://apidocs.io/illustration/python?workspaceFolder=Bokudirectpaymentsapi-Python&projectName=bokudirectpaymentsapi&step=createFile)

Name it "testSDK".

![Add a new project in PyCharm - Step 4](https://apidocs.io/illustration/python?workspaceFolder=Bokudirectpaymentsapi-Python&projectName=bokudirectpaymentsapi&step=nameFile)

In your python file you will be required to import the generated python library using the following code lines

```python
from bokudirectpaymentsapi.bokudirectpaymentsapi_client import BokudirectpaymentsapiClient
```

![Add a new project in PyCharm - Step 5](https://apidocs.io/illustration/python?workspaceFolder=Bokudirectpaymentsapi-Python&projectName=bokudirectpaymentsapi&libraryName=bokudirectpaymentsapi.bokudirectpaymentsapi_client&className=BokudirectpaymentsapiClient&step=projectFiles)

After this you can write code to instantiate an API client object, get a controller object and  make API calls. Sample code is given in the subsequent sections.

### 3. Run the Test Project

To run the file within your test project, right click on your Python file inside your Test project and click on `Run`

![Run Test Project - Step 1](https://apidocs.io/illustration/python?workspaceFolder=Bokudirectpaymentsapi-Python&projectName=bokudirectpaymentsapi&libraryName=bokudirectpaymentsapi.bokudirectpaymentsapi_client&className=BokudirectpaymentsapiClient&step=runProject)

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `country` | `string` | Country code in ISO 3166-1-alpha-2 standard<br>*Default*: `'jp'` |
| `environment` | Environment | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| `http_client_instance` | `HttpClient` | The Http Client passed from the sdk user for making requests |
| `override_http_client_configuration` | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| `http_call_back` | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| `timeout` | `float` | The value to use for connection timeout. <br> **Default: 60** |
| `max_retries` | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| `backoff_factor` | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| `retry_statuses` | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| `retry_methods` | `Array of string` | The http methods on which retry is to be done. <br> **Default: ['GET', 'PUT', 'GET', 'PUT']** |

The API client can be initialized as follows:

```python
from bokudirectpaymentsapi.bokudirectpaymentsapi_client import BokudirectpaymentsapiClient
from bokudirectpaymentsapi.configuration import Environment

client = BokudirectpaymentsapiClient(
    environment=Environment.PRODUCTION,
    country = 'jp',)
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| production | **Default** |
| environment2 | - |

## List of APIs

* [Consumer Registration](doc/controllers/consumer-registration.md)

## Classes Documentation

* [Utility Classes](doc/utility-classes.md)
* [HttpResponse](doc/http-response.md)
* [HttpRequest](doc/http-request.md)

