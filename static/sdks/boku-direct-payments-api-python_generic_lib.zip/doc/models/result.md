
# Result

The 'result' element is defined in every response type. It is used to convey the outcome of an API request.

## Structure

`Result`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`ResultStatusEnum`](../../doc/models/result-status-enum.md) | Required | The status of the operation |
| `reason_code` | `int` | Required | Provides additional information for the status |
| `message` | `string` | Required | Description of the reason code |
| `retriable` | `bool` | Required | **true** if the request can be retried; **false** otherwise |
| `retry_delay` | `int` | Optional | Minimum milliseconds to delay before re-trying request |
| `invalid_request_fields` | [`List of InvalidRequestField`](../../doc/models/invalid-request-field.md) | Optional | - |

## Example (as XML)

```xml
<result>
  <reason-code>0</reason-code>
  <message>Operation Successful</message>
  <retriable>false</retriable>
  <status>OK</status>
</result>
```

