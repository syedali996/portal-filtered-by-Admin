
# Optin Request Qr Info

## Structure

`OptinRequestQrInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`TypeEnum`](../../doc/models/type-enum.md) | Required | - |

## Example (as XML)

```xml
<OptinRequestQrInfo>
  <type>QR_CONTENT</type>
</OptinRequestQrInfo>
```

