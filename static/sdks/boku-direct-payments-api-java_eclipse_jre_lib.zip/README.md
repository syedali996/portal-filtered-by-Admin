
# Getting Started with Boku Direct Payments API

## Introduction

### API Security

Security is a significant consideration for payment platforms. As part of the registration process for each registered merchant account, merchants receive a security key used to authenticate communications in either direction.

Developers should consult the [Boku API Signature Authentication Guide](page:guides/api-signature-authentication-guide) for additional details with respect to implementing security on the Boku APIs.

### API Usage

When a consumer chooses to use a local payment-method (wallet), the consumer must go through an 'optin' flow to authenticate. This is accomplished using a redirect to the issuer's app or website where the consumer authenticates and completes the opt-in process.

After the consumer adds their local payment-method (wallet), as their registered payment method, the 'charge' method is used to charge the consumer's local payment-method.

If a customer decides to refund a transaction, the 'refund-charge' method can be used to refund the transaction.

### API Versioning

The Boku Payment Gateway API is versioned to provide support for changes to functionality without affecting existing integrations.  Each API URL includes version information that enables distinct functionality across different versions.

There are several types of changes that could result in a new API version:

1. New API functionality – new APIs, new parameters, additional information in responses, improved error reporting.
2. Deprecated API functionality – deprecated APIs, deprecated parameters, deprecated error messages.
3. Changes in functionality – existing functional behavior changes such as the returned result of a call. A warning is changed to an error.  Validation becomes stricter or more lenient.

In these cases, Boku will release a new API version through a new endpoint(s). When new versions of existing APIs are added, support for existing versions is maintained.  Unless otherwise stated, as a rule, compatibility is maintained across versions.  Prior supported endpoints should have unchanged behavior. If an API is deprecated and scheduled to be removed, a notice of not less than 6 months will be given.  Requests for extensions to this period can be considered.

Boku may make changes to the API within an existing version without changing the version number. An example of a non-versioning change would be the addition of an optional field to a request or to a response.

### API Calls

#### URL Scheme

All the below API calls are against URLs that follow the pattern,

`https://${api-node}.boku.com/${api-family}/${api-version}/${api-call}`

Definitions for the above placeholders:

* **api-node**: This follows the pattern '${country}-api4' (e.g. 'us-api4').
  * 'country' is the two letter country code of the end-user's payment-method against which the call is made.
  * The country code is required and is used for more efficient routing of the request.
  * The country code in the url must match the country code supplied in the `optin-request`.`country` element.
* **api-family**: Groups a family of related API methods.
  * In this API, family is either one of:
    * 'optin' - For interacting with the user or handset to obtain billing approval.
    * 'billing' - For actually performing billing operations against the user.
* **api-version**: In this version of the API, this value is always the string '3.0'.
  * Calls under different version numbers may be used in the future to introduce non-compatible API changes.
* **api-call**: The name particular API call or method to invoke, for example 'charge' or 'refund-charge'.
  * This usually matches the XML root element name, sans the '-request' suffix.

Fully qualified API call URLs are documented with each of the example calls detailed below.

## Building

Supported Java version is **8+**.

The generated code uses a few Maven dependencies e.g., Jackson, OkHttp,
and Apache HttpClient. The reference to these dependencies is already
added in the pom.xml file will be installed automatically. Therefore,
you will need internet access for a successful build.

* In order to open the client library in Eclipse click on `File -> Import`.

![Importing SDK into Eclipse - Step 1](https://apidocs.io/illustration/java?workspaceFolder=Boku%20Direct%20Payments%20API-Java&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPILib&rootNamespace=com.boku.jpapi4stage&groupId=BokuDirectPaymentsAPILib&artifactId=boku-direct-payments-apilib&version=3.0.0&step=import0)

* In the import dialog, select `Existing Java Project` and click `Next`.

![Importing SDK into Eclipse - Step 2](https://apidocs.io/illustration/java?workspaceFolder=Boku%20Direct%20Payments%20API-Java&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPILib&rootNamespace=com.boku.jpapi4stage&groupId=BokuDirectPaymentsAPILib&artifactId=boku-direct-payments-apilib&version=3.0.0&step=import1)

* Browse to locate the folder containing the source code. Select the detected location of the project and click `Finish`.

![Importing SDK into Eclipse - Step 3](https://apidocs.io/illustration/java?workspaceFolder=Boku%20Direct%20Payments%20API-Java&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPILib&rootNamespace=com.boku.jpapi4stage&groupId=BokuDirectPaymentsAPILib&artifactId=boku-direct-payments-apilib&version=3.0.0&step=import2)

* Upon successful import, the project will be automatically built by Eclipse after automatically resolving the dependencies.

![Importing SDK into Eclipse - Step 4](https://apidocs.io/illustration/java?workspaceFolder=Boku%20Direct%20Payments%20API-Java&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPILib&rootNamespace=com.boku.jpapi4stage&groupId=BokuDirectPaymentsAPILib&artifactId=boku-direct-payments-apilib&version=3.0.0&step=import3)

## Installation

The following section explains how to use the BokuDirectPaymentsAPILib library in a new project.

### 1. Starting a new project

For starting a new project, click the menu command `File > New > Project`.

![Add a new project in Eclipse](https://apidocs.io/illustration/java?workspaceFolder=Boku%20Direct%20Payments%20API-Java&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPILib&rootNamespace=com.boku.jpapi4stage&groupId=BokuDirectPaymentsAPILib&artifactId=boku-direct-payments-apilib&version=3.0.0&step=createNewProject0)

Next, choose `Maven > Maven Project` and click `Next`.

![Create a new Maven Project - Step 1](https://apidocs.io/illustration/java?workspaceFolder=Boku%20Direct%20Payments%20API-Java&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPILib&rootNamespace=com.boku.jpapi4stage&groupId=BokuDirectPaymentsAPILib&artifactId=boku-direct-payments-apilib&version=3.0.0&step=createNewProject1)

Here, make sure to use the current workspace by choosing `Use default Workspace location`, as shown in the picture below and click `Next`.

![Create a new Maven Project - Step 2](https://apidocs.io/illustration/java?workspaceFolder=Boku%20Direct%20Payments%20API-Java&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPILib&rootNamespace=com.boku.jpapi4stage&groupId=BokuDirectPaymentsAPILib&artifactId=boku-direct-payments-apilib&version=3.0.0&step=createNewProject2)

Following this, select the *quick start* project type to create a simple project with an existing class and a `main` method. To do this, choose `maven-archetype-quickstart` item from the list and click `Next`.

![Create a new Maven Project - Step 3](https://apidocs.io/illustration/java?workspaceFolder=Boku%20Direct%20Payments%20API-Java&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPILib&rootNamespace=com.boku.jpapi4stage&groupId=BokuDirectPaymentsAPILib&artifactId=boku-direct-payments-apilib&version=3.0.0&step=createNewProject3)

In the last step, provide a `Group Id` and `Artifact Id` as shown in the picture below and click `Finish`.

![Create a new Maven Project - Step 4](https://apidocs.io/illustration/java?workspaceFolder=Boku%20Direct%20Payments%20API-Java&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPILib&rootNamespace=com.boku.jpapi4stage&groupId=BokuDirectPaymentsAPILib&artifactId=boku-direct-payments-apilib&version=3.0.0&step=createNewProject4)

### 2. Add reference of the library project

The created Maven project manages its dependencies using its `pom.xml` file. In order to add a dependency on the *BokuDirectPaymentsAPILib* client library, double click on the `pom.xml` file in the `Package Explorer`. Opening the `pom.xml` file will render a graphical view on the canvas. Here, switch to the `Dependencies` tab and click the `Add` button as shown in the picture below.

![Adding dependency to the client library - Step 1](https://apidocs.io/illustration/java?workspaceFolder=Boku%20Direct%20Payments%20API-Java&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPILib&rootNamespace=com.boku.jpapi4stage&groupId=BokuDirectPaymentsAPILib&artifactId=boku-direct-payments-apilib&version=3.0.0&step=testProject0)

Clicking the `Add` button will open a dialog where you need to specify BokuDirectPaymentsAPILib in `Group Id`, boku-direct-payments-apilib in `Artifact Id` and 3.0.0 in the `Version` fields. Once added click `OK`. Save the `pom.xml` file.

![Adding dependency to the client library - Step 2](https://apidocs.io/illustration/java?workspaceFolder=Boku%20Direct%20Payments%20API-Java&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPILib&rootNamespace=com.boku.jpapi4stage&groupId=BokuDirectPaymentsAPILib&artifactId=boku-direct-payments-apilib&version=3.0.0&step=testProject1)

![Adding sample code](https://apidocs.io/illustration/java?workspaceFolder=Boku%20Direct%20Payments%20API-Java&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPILib&rootNamespace=com.boku.jpapi4stage&groupId=BokuDirectPaymentsAPILib&artifactId=boku-direct-payments-apilib&version=3.0.0&step=testProject2)

### 3. Write sample code

Once the `SimpleConsoleApp` is created, a file named `App.java` will be visible in the *Package Explorer* with a `main` method. This is the entry point for the execution of the created project.
Here, you can add code to initialize the client library and instantiate a *Controller* class. Sample code to initialize the client library and using controller methods is given in the subsequent sections.

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `country` | `String` | Country code in ISO 3166-1-alpha-2 standard<br>*Default*: `"jp"` |
| `environment` | Environment | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| `httpClientConfig` | [`ReadonlyHttpClientConfiguration`](doc/http-client-configuration.md) | Http Client Configuration instance. |

The API client can be initialized as follows:

```java
BokuDirectPaymentsAPIClient client = new BokuDirectPaymentsAPIClient.Builder()
    .httpClientConfig(configBuilder -> configBuilder
            .timeout(0))
    .environment(Environment.PRODUCTION)
    .country("jp")
    .build();
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| production | **Default** |
| environment2 | - |

## List of APIs

* [Consumer Registration](doc/controllers/consumer-registration.md)

## Classes Documentation

* [Utility Classes](doc/utility-classes.md)
* [HttpRequest](doc/http-request.md)
* [HttpResponse](doc/http-response.md)
* [HttpStringResponse](doc/http-string-response.md)
* [HttpContext](doc/http-context.md)
* [HttpBodyRequest](doc/http-body-request.md)
* [Headers](doc/headers.md)
* [ApiException](doc/api-exception.md)
* [Configuration Interface](doc/configuration-interface.md)
* [HttpClientConfiguration](doc/http-client-configuration.md)
* [HttpClientConfiguration.Builder](doc/http-client-configuration-builder.md)

