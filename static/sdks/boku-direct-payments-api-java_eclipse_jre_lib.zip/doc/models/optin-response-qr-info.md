
# Optin Response Qr Info

## Structure

`OptinResponseQrInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`TypeEnum`](../../doc/models/type-enum.md) | Required | - | TypeEnum getType() | setType(TypeEnum type) |
| `Source` | `String` | Required | - | String getSource() | setSource(String source) |

## Example (as XML)

```xml
<OptinResponseQrInfo>
  <type>QR_CONTENT</type>
  <source>source4</source>
</OptinResponseQrInfo>
```

