
# Cancel Optin Response

'cancel-optin' Response - General Elements

## Structure

`CancelOptinResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Result` | [`Result`](../../doc/models/result.md) | Required | The 'result' element is defined in every response type. It is used to convey the outcome of an API request. | Result getResult() | setResult(Result result) |
| `MerchantId` | `String` | Required | Boku assigned merchant ID<br>**Constraints**: *Maximum Length*: `50` | String getMerchantId() | setMerchantId(String merchantId) |
| `MerchantRequestId` | `String` | Required | Merchant assigned request ID<br>**Constraints**: *Maximum Length*: `50` | String getMerchantRequestId() | setMerchantRequestId(String merchantRequestId) |
| `OptinId` | `String` | Required | Boku assigned consumer opt-in ID<br>**Constraints**: *Maximum Length*: `24` | String getOptinId() | setOptinId(String optinId) |
| `OptinType` | [`OptinTypeEnum`](../../doc/models/optin-type-enum.md) | Optional | Which method to use to perform opt-in. | OptinTypeEnum getOptinType() | setOptinType(OptinTypeEnum optinType) |
| `OptinState` | [`OptinState`](../../doc/models/optin-state.md) | Optional | Gives the state of the opt-in at the time this response was returned | OptinState getOptinState() | setOptinState(OptinState optinState) |

## Example (as XML)

```xml
<cancel-optin-response>
  <result>
    <reason-code>0</reason-code>
    <message>Operation Successful</message>
    <retriable>false</retriable>
    <status>OK</status>
  </result>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-request-id>1002006</merchant-request-id>
  <optin-id>IVXecDoa2f6Y3oOqp1f7</optin-id>
  <optin-state>
    <optin-status>closed</optin-status>
    <country>DE</country>
    <network-id>de-super</network-id>
  </optin-state>
  <optin-type>hosted</optin-type>
</cancel-optin-response>
```

