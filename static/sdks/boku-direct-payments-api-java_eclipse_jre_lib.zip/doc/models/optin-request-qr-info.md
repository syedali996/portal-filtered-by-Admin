
# Optin Request Qr Info

## Structure

`OptinRequestQrInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`TypeEnum`](../../doc/models/type-enum.md) | Required | - | TypeEnum getType() | setType(TypeEnum type) |

## Example (as XML)

```xml
<OptinRequestQrInfo>
  <type>QR_CONTENT</type>
</OptinRequestQrInfo>
```

