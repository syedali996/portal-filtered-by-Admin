
# Optin Response Hosted

Provides information for proceeding with a hosted opt-in

## Structure

`OptinResponseHosted`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `OptinUrl` | `String` | Required | Boku provided URL that provides the opt-in UI for the consumer.<br>**Constraints**: *Maximum Length*: `2048` | String getOptinUrl() | setOptinUrl(String optinUrl) |
| `QrInfo` | [`OptinResponseQrInfo`](../../doc/models/optin-response-qr-info.md) | Optional | - | OptinResponseQrInfo getQrInfo() | setQrInfo(OptinResponseQrInfo qrInfo) |

## Example (as XML)

```xml
<hosted>
  <optin-url>https://www.issuer.com/optin/2032405</optin-url>
</hosted>
```

