
# Confirm Optin Response

'confirm-optin' Response - General Elements

## Structure

`ConfirmOptinResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Result` | [`Result`](../../doc/models/result.md) | Required | The 'result' element is defined in every response type. It is used to convey the outcome of an API request. | Result getResult() | setResult(Result result) |
| `Timestamp` | `String` | Optional | Time request was received ("YYYY-MM-DD hh:mm:ss")<br><br>All timestamps are in UTC<br>**Constraints**: *Pattern*: `^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$` | String getTimestamp() | setTimestamp(String timestamp) |
| `MerchantId` | `String` | Required | Boku assigned merchant ID<br>**Constraints**: *Maximum Length*: `50` | String getMerchantId() | setMerchantId(String merchantId) |
| `MerchantRequestId` | `String` | Required | Merchant assigned unique request id<br>**Constraints**: *Maximum Length*: `50` | String getMerchantRequestId() | setMerchantRequestId(String merchantRequestId) |
| `OptinRequestId` | `String` | Optional | The merchant assigned ID used as `merchant-request-id` in the original opt-in call<br>**Constraints**: *Maximum Length*: `50` | String getOptinRequestId() | setOptinRequestId(String optinRequestId) |
| `OptinId` | `String` | Optional | Boku assigned opt-in id<br>**Constraints**: *Maximum Length*: `24` | String getOptinId() | setOptinId(String optinId) |
| `OptinState` | [`OptinState`](../../doc/models/optin-state.md) | Optional | Gives the state of the opt-in at the time this response was returned | OptinState getOptinState() | setOptinState(OptinState optinState) |
| `PaymentMethod` | `String` | Optional | The payment method selected<br>**Constraints**: *Maximum Length*: `50` | String getPaymentMethod() | setPaymentMethod(String paymentMethod) |
| `OptinType` | `String` | Required, Constant | Which method to use to perform opt-in.<br>**Default**: `"hosted"` | String getOptinType() | setOptinType(String optinType) |

## Example (as XML)

```xml
<confirm-optin-response>
  <result>
    <reason-code>0</reason-code>
    <message>Operation Successful</message>
    <retriable>false</retriable>
    <status>OK</status>
  </result>
  <timestamp>2015-02-40 04:44:16</timestamp>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-request-id>1002004</merchant-request-id>
  <optin-request-id>1002001</optin-request-id>
  <optin-id>IVXecDoa2f6Y3oOqp1f7</optin-id>
  <optin-state>
    <optin-status>active</optin-status>
    <country>JP</country>
    <network-id>jp-super</network-id>
    <account-identifier>te****st@boku.com</account-identifier>
    <issuer-unique-user-id>cc1c4f3</issuer-unique-user-id>
  </optin-state>
  <optin-type>hosted</optin-type>
  <payment-method>superwallet</payment-method>
</confirm-optin-response>
```

